﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork3
{
    class Rectangle:Shape
    {
        public int Width { get; set; }
        public int Height { get; set; }
       public Rectangle(int height,int width)
        {
            this.Height = height;
            this.Width = width;
        }
        public bool isLegal()
        {
            if (Width <= 0 || Height <= 0)
            {
                throw new ArithmeticException("Invalid width/height! ");
            }
            return true;
        }
        public double getArea() {
            if (!isLegal()) return -1;
            return Width * Height;
        }
        public void GetInfo() {
            try
            {
                if (isLegal())
                {
                    Console.WriteLine("The Rectangle is {0} wide,{1}high,and has an area of{3}", Width, Height, getArea());
                }
                else Console.WriteLine("Invalid Shape");
            }
            catch {
                throw new Exception("Invalid info!");
            }
        }
    }
}
