﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork3
{
   
    class ShapeFactory
    {
        
        static void main() {
            Shape[] Shape = new Shape[10];
            for(int i = 0; i < 10; i++)
            {  int r1 = new Random().Next(100) + 1;
                int r2 = new Random().Next(100) + 1;
                int r3 = new Random().Next(100) + 1;
                int k = new Random().Next(1,4);
                switch (k)
                {
                    case 1:Shape[i] = new Triangle(r1, r2, r3);
                              Shape[i].GetInfo();
                              Console.ReadLine();
                        break;
                    case 2: Shape[i] = new Rectangle(r1, r2);
                               Shape[i].GetInfo();
                               Console.ReadLine();
                        break;
                    case 3: Shape[i] = new Square(r1);
                                Shape[i].GetInfo();
                                Console.ReadLine();
                        break;
                    default:return;
                }
                
                Console.ReadKey();
            }
            Console.WriteLine("1");
            Console.ReadLine();
        }
    }
}
