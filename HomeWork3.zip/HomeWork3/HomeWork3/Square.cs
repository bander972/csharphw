﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork3
{
    internal class Square:Shape
    {
        public int Length { get; set; }
        
        public Square(int length)
        {
            this.Length = length;
        }
        public  bool isLegal() {
            if (Length <= 0 )
            {
                throw new ArithmeticException("Error! Invalid property! length and width is not usable!");
            }
            return true;
        }

        public  double getArea()
        { if (!isLegal()) return -1;
            return Length * Length;
        }
        public  void GetInfo()
        {
            try {
                if (isLegal())
                {
                    Console.WriteLine("this square has a edge length:{0},and its area is{1}", Length, getArea());
                }
                else Console.WriteLine("Invalid Shape");
            }
            catch
            {
                throw new NotImplementedException();
            }
        }
    }
}
