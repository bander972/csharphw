﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork3
{
   public interface Shape
    {
  
        bool isLegal();
        double getArea();
        void GetInfo();
    }
}
